//-----------------------------------------------------------------------------
//  File:         nao_team_1.java (to be used in a Webots java controllers)
//  Date:         May 15, 2008
//  Description:  !!! DO NOT MODIFY OR REMOVE THIS FILE !!!
//                It is necessary to compile and execute the "nao_team_1" controller.
//                Your controller implementation should go in the other .java files
//  Project:      Robotstadium, the online robot soccer competition
//  Author:       Yvan Bourquin, Cyberbotics Ltd.
//-----------------------------------------------------------------------------

public abstract class nao_team_1 extends SoccerPlayer {
}
